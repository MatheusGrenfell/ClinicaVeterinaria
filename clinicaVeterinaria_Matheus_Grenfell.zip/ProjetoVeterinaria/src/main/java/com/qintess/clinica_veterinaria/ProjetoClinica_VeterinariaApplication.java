package com.qintess.clinica_veterinaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({
	"com.qintess.clinica_veterinaria.controllers",
	"com.qintess.clinica_veterinaria.repos",
	"com.qintess.clinica_veterinaria.services"
})
public class ProjetoClinica_VeterinariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoClinica_VeterinariaApplication.class, args);
		
	}
}
