package com.qintess.clinica_veterinaria.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import com.qintess.clinica_veterinaria.models.Animal;
import com.qintess.clinica_veterinaria.models.Atendimento;
import com.qintess.clinica_veterinaria.models.Veterinario;
import com.qintess.clinica_veterinaria.services.AnimalService;
import com.qintess.clinica_veterinaria.services.AtendimentoService;
import com.qintess.clinica_veterinaria.services.VeterinarioService;

@Controller
@RequestMapping("/cadastraAtendimento")
public class CadastraAtendimentoController {
	
	@Autowired
	AnimalService animalService;
	@Autowired
	AtendimentoService atendimentoService;
	@Autowired 
	VeterinarioService veterinarioService;
	
	
	@RequestMapping("")
	public String carregaAtendimento(Model model) {
		model.addAttribute("animal", new Animal());
		model.addAttribute("animais", animalService.buscaTodos());
		model.addAttribute("atendimento", new Atendimento());
		model.addAttribute("atendimentos",atendimentoService.buscaTodos());
		model.addAttribute("veterinario", new Veterinario());
		model.addAttribute("veterinarios", veterinarioService.buscaTodos());
			
		return "cadastraAtendimento";
	}
	
	@RequestMapping("/salva")
	public String salvaAtendimento(@ModelAttribute Atendimento atendimento, Animal animal,Veterinario veterinario) {
		if(atendimento.getId() == 0) {
			atendimentoService.insere(atendimento);
			animalService.insere(animal);
		}else {
			atendimentoService.altera(atendimento);
			animalService.altera(animal);
		}
		return "redirect:/cadastraAtendimento";
	}
	
	@RequestMapping("/altera/{id}")
	public String alteraAtendimento(@PathVariable(name = "id")int id,Model model) {
		
//		Atendimento atendimento = atendimentoService.buscaPorId(id);
		model.addAttribute("atendimento", atendimentoService.buscaPorId(id));
		model.addAttribute("atendimentos", atendimentoService.buscaTodos());
		model.addAttribute("animal", animalService.buscaPorId(id));
		model.addAttribute("animais", animalService.buscaTodos());

		return"cadastraAtendimento";
	}
	
	@RequestMapping("/deleta/{id}")
	public String deletaAtendimento(@PathVariable(name = "id")int id) {
		Atendimento atendimento = atendimentoService.buscaPorId(id);
		Animal animal = animalService.buscaPorId(id);	
		
		
		animalService.deleta(animal);
		atendimentoService.deleta(atendimento);
		
		return "redirect:/cadastraAtendimento";
	}
	
	

}
