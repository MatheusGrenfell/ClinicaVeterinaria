package com.qintess.clinica_veterinaria.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class IndexController {
	
	@RequestMapping("")
	public String carregamentoIndex() {
		return "index";
	}
	
}
