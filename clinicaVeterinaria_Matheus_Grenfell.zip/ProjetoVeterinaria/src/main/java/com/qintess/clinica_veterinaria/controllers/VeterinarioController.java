package com.qintess.clinica_veterinaria.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.qintess.clinica_veterinaria.models.Veterinario;
import com.qintess.clinica_veterinaria.services.VeterinarioService;

@Controller
@RequestMapping("/cadastraVeterinario")
public class VeterinarioController {
	@Autowired
	VeterinarioService veterinarioService;

	@RequestMapping("")
	public String carrega(Model model) {
		model.addAttribute("veterinario", new Veterinario());
		model.addAttribute("veterinarios", veterinarioService.buscaTodos());
		return "cadastraVeterinario";
	}

	@RequestMapping("/salva")
	public String salvaVeterinario(@ModelAttribute Veterinario veterinario) {
		if(veterinario.getId() == 0) {
			veterinarioService.insere(veterinario);
		}else {
			veterinarioService.altera(veterinario);
		}
		return "redirect:/cadastraVeterinario";
	}

	@RequestMapping("/deleta/{id}")
	public String deletaVeterinario(@PathVariable(name = "id")int id) {
		Veterinario veterinario = veterinarioService.buscaPorId(id);
		veterinarioService.deleta(veterinario);
		return "redirect:/cadastraVeterinario";
	}

	@RequestMapping("/altera/{id}")
	public String AlteraVeterinario(@PathVariable(name = "id")int id,Model model) {

		Veterinario veterinario = veterinarioService.buscaPorId(id);
		model.addAttribute("veterinario", veterinarioService.buscaPorId(id));
		model.addAttribute("veterinarios", veterinarioService.buscaTodos());

		return"cadastraVeterinario";
	}


}
