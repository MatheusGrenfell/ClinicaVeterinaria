package com.qintess.clinica_veterinaria.models;

import java.time.LocalDate;
import java.time.LocalTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Animal {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(nullable = false)
	private String nome;

	@Column(nullable = false)
	private String nomeDono;

	@Column(nullable = false)
	private String especie;

	@Column(nullable = false)
	private String raca;

	@Column(nullable = false)
	private String idadeAnimal;

	@Column(nullable = false)
	private String cpf;

	@Column(nullable = false)
	private String endereco;

	@Column(nullable = false)
	private String telefone;

	@Column(nullable = false)
	private String ConsultaMarcada;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dataAtendimento;

	@Column(nullable = false)
	private LocalTime horaAtendimento;

	@ManyToOne(fetch = FetchType.LAZY)	
	private Atendimento atendimento;

	public Animal() {}

	public Animal(int id, String nome, String nomeDono, String especie, String raca, String idadeAnimal, String cpf,
			String endereco, String telefone, String consultaMarcada, LocalDate dataAtendimento,
			LocalTime horaAtendimento, Atendimento atendimento) {
		this.id = id;
		this.nome = nome;
		this.nomeDono = nomeDono;
		this.especie = especie;
		this.raca = raca;
		this.idadeAnimal = idadeAnimal;
		this.cpf = cpf;
		this.endereco = endereco;
		this.telefone = telefone;
		ConsultaMarcada = consultaMarcada;
		this.dataAtendimento = dataAtendimento;
		this.horaAtendimento = horaAtendimento;
		this.atendimento = atendimento;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getNomeDono() {
		return nomeDono;
	}


	public void setNomeDono(String nomeDono) {
		this.nomeDono = nomeDono;
	}


	public String getEspecie() {
		return especie;
	}


	public void setEspecie(String especie) {
		this.especie = especie;
	}


	public String getRaca() {
		return raca;
	}


	public void setRaca(String raca) {
		this.raca = raca;
	}


	public String getIdadeAnimal() {
		return idadeAnimal;
	}


	public void setIdadeAnimal(String idadeAnimal) {
		this.idadeAnimal = idadeAnimal;
	}


	public String getCpf() {
		return cpf;
	}


	public void setCpf(String cpf) {
		this.cpf = cpf;
	}


	public String getEndereco() {
		return endereco;
	}


	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}


	public String getTelefone() {
		return telefone;
	}


	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}


	public String getConsultaMarcada() {
		return ConsultaMarcada;
	}


	public void setConsultaMarcada(String consultaMarcada) {
		ConsultaMarcada = consultaMarcada;
	}


	public LocalDate getDataAtendimento() {
		return dataAtendimento;
	}


	public void setDataAtendimento(LocalDate dataAtendimento) {
		this.dataAtendimento = dataAtendimento;
	}


	public LocalTime getHoraAtendimento() {
		return horaAtendimento;
	}


	public void setHoraAtendimento(LocalTime horaAtendimento) {
		this.horaAtendimento = horaAtendimento;
	}


	public Atendimento getAtendimento() {
		return atendimento;
	}


	public void setAtendimento(Atendimento atendimento) {
		this.atendimento = atendimento;
	}

}
