package com.qintess.clinica_veterinaria.models;


import java.util.ArrayList;
import java.util.List;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class Atendimento {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne
	private Animal animal;

	@ElementCollection(targetClass = Exame.class)
	private List<Exame>exames = new ArrayList<Exame>();

	public Atendimento() {

	}
	public Atendimento(int id, Animal animal, List<Exame> exames) {
		this.id = id;
		this.animal = animal;
		this.exames = exames;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public List<Exame> getExames() {
		return exames;
	}
	public void setExames(List<Exame> exames) {
		this.exames = exames;
	}

	public Animal getAnimal() {
		return animal;
	}
	public void setAnimal(Animal animal) {
		this.animal = animal;
	}

}
