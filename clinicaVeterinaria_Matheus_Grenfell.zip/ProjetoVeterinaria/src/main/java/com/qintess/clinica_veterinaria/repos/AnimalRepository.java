package com.qintess.clinica_veterinaria.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.qintess.clinica_veterinaria.models.Animal;
@Repository
@EnableTransactionManagement
public interface AnimalRepository extends JpaRepository<Animal, Integer> {


}
