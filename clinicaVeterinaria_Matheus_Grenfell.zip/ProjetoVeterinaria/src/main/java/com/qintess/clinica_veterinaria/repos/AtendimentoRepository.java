package com.qintess.clinica_veterinaria.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qintess.clinica_veterinaria.models.Atendimento;

public interface AtendimentoRepository extends JpaRepository<Atendimento, Integer>{

}
