package com.qintess.clinica_veterinaria.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qintess.clinica_veterinaria.models.Veterinario;

public interface VeterinarioRepository  extends JpaRepository<Veterinario, Integer>{

}
