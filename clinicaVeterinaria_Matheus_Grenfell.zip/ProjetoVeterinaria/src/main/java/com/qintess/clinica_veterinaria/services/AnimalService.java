package com.qintess.clinica_veterinaria.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qintess.clinica_veterinaria.models.Animal;
import com.qintess.clinica_veterinaria.repos.AnimalRepository;

@Service
public class AnimalService {
	@Autowired
	AnimalRepository animalRepositorio;

	public void insere(Animal animal) {
		animalRepositorio.save(animal);
	}

	public List<Animal> buscaTodos() {
		return animalRepositorio.findAll();
	}

	public Animal buscaPorId(int id) {
		Optional<Animal> animalOp = animalRepositorio.findById(id);
		Animal animal = new Animal();
		animal.setId(animalOp.get().getId());
		animal.setNome(animalOp.get().getNome());
		animal.setNomeDono(animalOp.get().getNomeDono());
		animal.setEspecie(animalOp.get().getEspecie());
		animal.setRaca(animalOp.get().getRaca());
		animal.setIdadeAnimal(animalOp.get().getIdadeAnimal());
		animal.setCpf(animalOp.get().getCpf());
		animal.setEndereco(animalOp.get().getEndereco());
		animal.setTelefone(animalOp.get().getTelefone());
		animal.setConsultaMarcada(animalOp.get().getConsultaMarcada());
		animal.setDataAtendimento(animalOp.get().getDataAtendimento());
		animal.setHoraAtendimento(animalOp.get().getHoraAtendimento());
		animal.setAtendimento(animalOp.get().getAtendimento());


		return animal;
	}

	public void deleta(Animal animal) {
		animalRepositorio.delete(animal);
	}

	public void altera(Animal animal) {
		if(animalRepositorio.existsById(animal.getId())) {
			animalRepositorio.save(animal);
		}
	} 

}
