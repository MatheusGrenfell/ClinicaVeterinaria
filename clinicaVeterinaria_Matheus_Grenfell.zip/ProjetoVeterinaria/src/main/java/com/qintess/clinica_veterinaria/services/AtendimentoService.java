package com.qintess.clinica_veterinaria.services;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qintess.clinica_veterinaria.models.Atendimento;
import com.qintess.clinica_veterinaria.repos.AnimalRepository;
import com.qintess.clinica_veterinaria.repos.AtendimentoRepository;

@Service
public class AtendimentoService {

	@Autowired
	AtendimentoRepository atendimentoRepository;
	
	@Autowired
	AnimalRepository animalRepository;
	
	public void insere(Atendimento atendimento) {
		atendimentoRepository.save(atendimento);
	}
	
	public List<Atendimento> buscaTodos() {
		return atendimentoRepository.findAll();
	}
	
	public Atendimento buscaPorId(int id) {
		Optional<Atendimento> atendimentoOp = atendimentoRepository.findById(id);
		Atendimento atendimento = new Atendimento();
		atendimento.setId(atendimentoOp.get().getId());
		atendimento.setAnimal(atendimentoOp.get().getAnimal());
		atendimento.setExames(atendimentoOp.get().getExames());
		
		return atendimento;
	}
	
	public void deleta(Atendimento atendimento) {
		atendimentoRepository.delete(atendimento);
	}
	
	public void altera(Atendimento atendimento) {
		if(atendimentoRepository.existsById(atendimento.getId())) {
			atendimentoRepository.save(atendimento);
		}
	} 
	
}
