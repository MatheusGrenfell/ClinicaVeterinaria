package com.qintess.clinica_veterinaria.services;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qintess.clinica_veterinaria.models.Veterinario;
import com.qintess.clinica_veterinaria.repos.VeterinarioRepository;

@Service
public class VeterinarioService {
	@Autowired
	VeterinarioRepository veterinarioRepository;

	public void insere(Veterinario veterinario) {
		veterinarioRepository.save(veterinario);
	}

	public List<Veterinario> buscaTodos(){
		return veterinarioRepository.findAll();
	}

	public Veterinario buscaPorId(int id) {
		Optional<Veterinario> veterinarioOp = veterinarioRepository.findById(id);
		Veterinario veterinario = new Veterinario();
		veterinario.setId(veterinarioOp.get().getId());
		veterinario.setCrv(veterinarioOp.get().getCrv());
		veterinario.setNome(veterinarioOp.get().getNome());
		veterinario.setEspecialidades(veterinarioOp.get().getEspecialidades());
		veterinario.setEndereco(veterinarioOp.get().getEndereco());
		veterinario.setTelefone(veterinarioOp.get().getTelefone());
		
		return veterinario;	
	}
	
	public void deleta(Veterinario veterinario) {
		veterinarioRepository.delete(veterinario);
	}
	
	public void altera(Veterinario veterinario) {
		if (veterinarioRepository.existsById(veterinario.getId())) {
			veterinarioRepository.save(veterinario);
		}
	}
	

}	
