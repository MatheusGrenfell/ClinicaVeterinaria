package com.qintess.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
